Program: ESBDates v3.0.1 Released: 7 September 2001

Purpose: Freeware Date/Time Routine Collection for Delphi.

More Info: See ESBDates.TXT

Installation: Run Setup.exe. 
Place PAS file in Library Path. 

Status: Freeware, freely distributable

Contact: Glenn Crouch mailto:support@esbconsult.com.au

There is a support Conference available at:
http://e-fora.net:8080/~ESB

Note: The document Calendar23.txt has been included with
permission from the author.
